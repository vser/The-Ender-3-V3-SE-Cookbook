------------------------------------------------------------------------------
 固件适用机型及主板版本

 打印机型号：Ender-3 V3 SE
 打印机主板版本号： HWCR4NS200320C13
说明：
  该固件为Ender-3V3 SE出厂版本，支持十国语言。
  
屏幕更新说明：
    1. 在电脑端格式化TF卡，分配单元大小选择4096。
    2. 将文件夹“TJC_SET”放入TF卡。
    3. 关闭打印机，将TF卡插入屏幕左侧卡槽。
    4. 重启等待更新完成。
    5. 完成更新后取出TF卡，并删除里面的文件。

主板更新：
   1. 在电脑端格式化SD卡，分配单元大小选择4096。
   2. 将固件文件“Ender-3 V3 SE_HWCR4NS200320C13_SWV1.0.4_GD303_20230804.bin”放入SD卡中。
   3. 关闭打印机，将SD卡插入主板卡槽。
   4. 重启等待更新完成。
   5. 完成更新后取出SD卡，并删除里面的bin文件。
-------------------------------------------------------------------------------
Printer: Ender-3 V3 SE
Printer Mainboard: HWCR4NS200320C13
Notes: 
  The firmware is Ender-3V3 SE Factory standard version，Support ten languages。
  
Display firmware update：
    1. Format the SD card on the computer side, and select 4096 for the allocation unit size.
    2. Put the file "TJC_SET" into the SD card.
    3. Turn off the printer and Insert the TF card into the card slot on the left side of the screen.
    4. Reboot and wait for the update to finish.
    5. After finishing the update, remove the TF card and delete the files inside.

Mainboard firmware update:
   1. Format the TF card on the computer side, and select 4096 for the allocation unit size.
   2. Put the firmware file "Ender-3 V3 SE_HWCR4NS200320C13_SWV1.0.4_GD303_20230804.bin" into the root directory of SD card.
   3. Turn off the printer and insert the TF card into the card slot on the motherboard.  
   4. Reboot and wait for the update to finish.
   5. After finishing the update, remove the TF card from the motherboard slot and delete the bin file inside.

